-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: mysql    Database: payment
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payment_channel`
--

DROP TABLE IF EXISTS `payment_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_channel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `appid` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `sp_mchid` varchar(128) NOT NULL,
  `begin_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `bean_name` varchar(256) DEFAULT NULL,
  `creator_id` bigint DEFAULT NULL,
  `creator_name` varchar(128) DEFAULT NULL,
  `modifier_id` bigint DEFAULT NULL,
  `modifier_name` varchar(128) DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=502 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付渠道';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_channel`
--

LOCK TABLES `payment_channel` WRITE;
/*!40000 ALTER TABLE `payment_channel` DISABLE KEYS */;
INSERT INTO `payment_channel` VALUES (501,'100001','微信支付','1900007XXX','2022-05-02 18:49:48','2099-11-02 18:49:56',0,'wePayChannel',1,'admin111',NULL,NULL,'2022-11-02 10:51:31',NULL);
/*!40000 ALTER TABLE `payment_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_div_pay_trans`
--

DROP TABLE IF EXISTS `payment_div_pay_trans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_div_pay_trans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `out_no` varchar(128) DEFAULT NULL,
  `trans_no` varchar(128) DEFAULT NULL,
  `amount` bigint NOT NULL DEFAULT '0',
  `success_time` datetime DEFAULT NULL,
  `adjust_id` bigint DEFAULT NULL,
  `adjust_name` varchar(128) DEFAULT NULL,
  `adjust_time` datetime DEFAULT NULL,
  `pay_trans_id` bigint NOT NULL,
  `creator_id` bigint DEFAULT NULL,
  `creator_name` varchar(128) DEFAULT NULL,
  `modifier_id` bigint DEFAULT NULL,
  `modifier_name` varchar(128) DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime DEFAULT NULL,
  `shop_channel_id` bigint DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=501 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付分账交易';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_div_pay_trans`
--

LOCK TABLES `payment_div_pay_trans` WRITE;
/*!40000 ALTER TABLE `payment_div_pay_trans` DISABLE KEYS */;
INSERT INTO `payment_div_pay_trans` VALUES (1,'1','dasdad',10,'2022-11-13 11:54:36',NULL,NULL,NULL,551,1,'admin112',NULL,NULL,'2022-11-13 03:55:02',NULL,501,0);
/*!40000 ALTER TABLE `payment_div_pay_trans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_div_refund_trans`
--

DROP TABLE IF EXISTS `payment_div_refund_trans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_div_refund_trans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `out_no` varchar(128) DEFAULT NULL,
  `trans_no` varchar(128) DEFAULT NULL,
  `amount` bigint NOT NULL DEFAULT '0',
  `success_time` datetime DEFAULT NULL,
  `adjust_id` bigint DEFAULT NULL,
  `adjust_name` varchar(128) DEFAULT NULL,
  `adjust_time` datetime DEFAULT NULL,
  `refund_trans_id` bigint NOT NULL,
  `div_pay_trans_id` bigint NOT NULL,
  `creator_id` bigint DEFAULT NULL,
  `creator_name` varchar(128) DEFAULT NULL,
  `modifier_id` bigint DEFAULT NULL,
  `modifier_name` varchar(128) DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime DEFAULT NULL,
  `shop_channel_id` bigint DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=521 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='退款分账交易';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_div_refund_trans`
--

LOCK TABLES `payment_div_refund_trans` WRITE;
/*!40000 ALTER TABLE `payment_div_refund_trans` DISABLE KEYS */;
INSERT INTO `payment_div_refund_trans` VALUES (1,'1','1234',10,'2023-11-02 10:51:31',NULL,NULL,NULL,501,1,1,'admin111',NULL,NULL,'2021-11-02 10:51:31',NULL,501,0);
/*!40000 ALTER TABLE `payment_div_refund_trans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_ledger`
--

DROP TABLE IF EXISTS `payment_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_ledger` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `out_no` varchar(128) NOT NULL,
  `trans_no` varchar(128) NOT NULL,
  `amount` bigint NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `success_time` datetime DEFAULT NULL,
  `type` tinyint NOT NULL DEFAULT '0',
  `adjust_id` bigint DEFAULT NULL,
  `adjust_name` varchar(128) DEFAULT NULL,
  `adjust_time` datetime DEFAULT NULL,
  `shop_channel_id` bigint NOT NULL,
  `trans_id` bigint DEFAULT NULL,
  `check_time` datetime DEFAULT NULL,
  `creator_id` bigint DEFAULT NULL,
  `creator_name` varchar(128) DEFAULT NULL,
  `modifier_id` bigint DEFAULT NULL,
  `modifier_name` varchar(128) DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime DEFAULT NULL,
  `channel_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=502 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='对账台账';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_ledger`
--

LOCK TABLES `payment_ledger` WRITE;
/*!40000 ALTER TABLE `payment_ledger` DISABLE KEYS */;
INSERT INTO `payment_ledger` VALUES (501,'1111','1111',100,5,'2022-11-07 23:08:50',1,NULL,NULL,NULL,501,551,NULL,1,'admin12',NULL,NULL,'2022-11-07 15:09:53',NULL,NULL);
/*!40000 ALTER TABLE `payment_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_pay_trans`
--

DROP TABLE IF EXISTS `payment_pay_trans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_pay_trans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `out_no` varchar(128) DEFAULT NULL,
  `trans_no` varchar(128) DEFAULT NULL,
  `amount` bigint NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `success_time` datetime DEFAULT NULL,
  `adjust_id` bigint DEFAULT NULL,
  `adjust_name` varchar(128) DEFAULT NULL,
  `adjust_time` datetime DEFAULT NULL,
  `sp_openid` varchar(128) DEFAULT NULL,
  `time_expire` datetime DEFAULT NULL,
  `time_begin` datetime DEFAULT NULL,
  `shop_channel_id` bigint NOT NULL,
  `creator_id` bigint DEFAULT NULL,
  `creator_name` varchar(128) DEFAULT NULL,
  `modifier_id` bigint DEFAULT NULL,
  `modifier_name` varchar(128) DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime DEFAULT NULL,
  `prepay_id` varchar(128) DEFAULT NULL,
  `div_amount` bigint NOT NULL DEFAULT '0',
  `in_refund` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=855 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='支付交易';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_pay_trans`
--

LOCK TABLES `payment_pay_trans` WRITE;
/*!40000 ALTER TABLE `payment_pay_trans` DISABLE KEYS */;
INSERT INTO `payment_pay_trans` VALUES (551,'551','12222',100,7,'2022-11-06 01:05:42',NULL,NULL,NULL,'1111','2022-11-07 01:05:57',NULL,501,1,'admin',NULL,NULL,'2022-11-06 17:06:30',NULL,'66666',10,0),(768,'768','2111',1000,1,'2022-11-15 14:29:49',NULL,NULL,NULL,NULL,'2022-12-15 14:29:57',NULL,501,1,'admin',NULL,NULL,'2022-11-15 14:30:18',NULL,'55555',5,0);
/*!40000 ALTER TABLE `payment_pay_trans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_refund_trans`
--

DROP TABLE IF EXISTS `payment_refund_trans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_refund_trans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `out_no` varchar(128) DEFAULT NULL,
  `trans_no` varchar(128) DEFAULT NULL,
  `amount` bigint NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `success_time` datetime DEFAULT NULL,
  `adjust_id` bigint DEFAULT NULL,
  `adjust_name` varchar(128) DEFAULT NULL,
  `adjust_time` datetime DEFAULT NULL,
  `user_received_account` varchar(128) DEFAULT NULL,
  `pay_trans_id` bigint NOT NULL,
  `shop_channel_id` bigint NOT NULL,
  `creator_id` bigint DEFAULT NULL,
  `creator_name` varchar(128) DEFAULT NULL,
  `modifier_id` bigint DEFAULT NULL,
  `modifier_name` varchar(128) DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime DEFAULT NULL,
  `div_amount` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=598 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='退款交易';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_refund_trans`
--

LOCK TABLES `payment_refund_trans` WRITE;
/*!40000 ALTER TABLE `payment_refund_trans` DISABLE KEYS */;
INSERT INTO `payment_refund_trans` VALUES (501,'501','34444',100,1,'2022-11-07 01:07:11',NULL,NULL,NULL,NULL,551,501,1,'admin',NULL,NULL,'2022-11-06 17:07:43',NULL,0),(597,'597','12121',200,1,'2022-11-15 14:45:46',NULL,NULL,NULL,NULL,768,501,1,'admin',NULL,NULL,'2022-11-15 14:46:06',NULL,2);
/*!40000 ALTER TABLE `payment_refund_trans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_shop_channel`
--

DROP TABLE IF EXISTS `payment_shop_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_shop_channel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `shop_id` bigint NOT NULL,
  `sub_mchid` varchar(128) NOT NULL,
  `channel_id` bigint NOT NULL,
  `creator_id` bigint DEFAULT NULL,
  `creator_name` varchar(128) DEFAULT NULL,
  `modifier_id` bigint DEFAULT NULL,
  `modifier_name` varchar(128) DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gmt_modified` datetime DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商铺支付渠道账户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_shop_channel`
--

LOCK TABLES `payment_shop_channel` WRITE;
/*!40000 ALTER TABLE `payment_shop_channel` DISABLE KEYS */;
INSERT INTO `payment_shop_channel` VALUES (501,1,'1900008XXX',501,1,'admin111',NULL,NULL,'2022-11-02 10:53:41',NULL,0);
/*!40000 ALTER TABLE `payment_shop_channel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-02  9:50:13
